Whatever map you want to test with this must be named "Test Copy" without the quotes because there
is no map selection in this version.